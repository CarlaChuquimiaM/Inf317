﻿namespace calculadoraInfix
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tt1 = new System.Windows.Forms.TextBox();
            this.tt2 = new System.Windows.Forms.TextBox();
            this.res = new System.Windows.Forms.TextBox();
            this.bev = new System.Windows.Forms.Button();
            this.bbor = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tt1
            // 
            this.tt1.Location = new System.Drawing.Point(176, 14);
            this.tt1.Multiline = true;
            this.tt1.Name = "tt1";
            this.tt1.Size = new System.Drawing.Size(243, 38);
            this.tt1.TabIndex = 0;
            this.tt1.TextChanged += new System.EventHandler(this.tt1_TextChanged);
            // 
            // tt2
            // 
            this.tt2.Location = new System.Drawing.Point(176, 77);
            this.tt2.Multiline = true;
            this.tt2.Name = "tt2";
            this.tt2.Size = new System.Drawing.Size(243, 38);
            this.tt2.TabIndex = 0;
            this.tt2.TextChanged += new System.EventHandler(this.tt2_TextChanged);
            // 
            // res
            // 
            this.res.Location = new System.Drawing.Point(176, 202);
            this.res.Multiline = true;
            this.res.Name = "res";
            this.res.Size = new System.Drawing.Size(243, 38);
            this.res.TabIndex = 0;
            this.res.TextChanged += new System.EventHandler(this.res_TextChanged);
            // 
            // bev
            // 
            this.bev.Location = new System.Drawing.Point(187, 137);
            this.bev.Name = "bev";
            this.bev.Size = new System.Drawing.Size(94, 42);
            this.bev.TabIndex = 1;
            this.bev.Text = "Evaluar";
            this.bev.UseVisualStyleBackColor = true;
            this.bev.Click += new System.EventHandler(this.bev_Click);
            // 
            // bbor
            // 
            this.bbor.Location = new System.Drawing.Point(311, 137);
            this.bbor.Name = "bbor";
            this.bbor.Size = new System.Drawing.Size(94, 42);
            this.bbor.TabIndex = 1;
            this.bbor.Text = "Borrar";
            this.bbor.UseVisualStyleBackColor = true;
            this.bbor.Click += new System.EventHandler(this.bbor_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(28, 24);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 2;
            this.textBox4.Text = "INFIJA";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(28, 86);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 2;
            this.textBox5.Text = "POSTFIJA";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(28, 211);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "RESPUESTA";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 261);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.bbor);
            this.Controls.Add(this.bev);
            this.Controls.Add(this.res);
            this.Controls.Add(this.tt2);
            this.Controls.Add(this.tt1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tt1;
        private System.Windows.Forms.TextBox tt2;
        private System.Windows.Forms.TextBox res;
        private System.Windows.Forms.Button bev;
        private System.Windows.Forms.Button bbor;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox1;
    }
}

