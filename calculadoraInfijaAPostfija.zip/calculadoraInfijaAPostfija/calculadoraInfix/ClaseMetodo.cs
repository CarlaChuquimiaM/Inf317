﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadoraInfix
{
    class ClaseMetodo
    {
        public string Postfijo(string infijo)
        {
            string res = "";
            Stack<char> stack = new Stack<char>();

            for (int i = 0; i < infijo.Length; i++)
            {
                char c = infijo[i];
                if (char.IsLetterOrDigit(c))
                {res += c; }
                else if (c == '(')
                {stack.Push(c);}
                else if (c == ')')
                { while (stack.Count > 0 && stack.Peek() != '(')
                    { res += stack.Pop();}
                    stack.Pop(); // Quitar el '(' de la pila
                }
                else if (IsOperator(c))
                {
                    while (stack.Count > 0 && Precedencia(stack.Peek()) >= Precedencia(c))
                    {
                        res += stack.Pop();
                    }
                    stack.Push(c);
                }
            }
            while (stack.Count > 0)
            { res += stack.Pop();}
            return res;
        }

        private bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '*' || c == '/';
        }

        private int Precedencia(char op)
        {
            if (op == '+' || op == '-')
                return 1;
            if (op == '*' || op == '/')
                return 2;
            return 0;
        }
    }
}
