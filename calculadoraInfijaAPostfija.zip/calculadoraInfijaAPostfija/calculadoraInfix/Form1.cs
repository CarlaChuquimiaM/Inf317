﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadoraInfix
{
    public partial class Form1 : Form
    {
        string x1, x2;
        ClaseMetodo metodo = new ClaseMetodo();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bbor_Click(object sender, EventArgs e)
        {
            tt1.Clear();
            tt2.Clear();
            res.Clear();
        }

        private void bev_Click(object sender, EventArgs e)
        {
            x1 = tt1.Text;
            string x2 = metodo.Postfijo(x1);
            tt2.Text = x2;
            x1 = tt1.Text;
            double resultado = metodo.EvaluarPostfijo(x2);
            res.Text = resultado.ToString();
        }

        private void res_TextChanged(object sender, EventArgs e)
        {

        }

        private void tt2_TextChanged(object sender, EventArgs e)
        {
            tt2.Text = tt2.Text + x2;
        }

        private void tt1_TextChanged(object sender, EventArgs e)
        {
            x1 = tt1.Text;
        }
        public class ClaseMetodo
        {
            public string Postfijo(string infijo)
            {
                string res = "";
                Stack<char> stack = new Stack<char>();

                for (int i = 0; i < infijo.Length; i++)
                {
                    char c = infijo[i];

                    // Si el carácter es un operando, lo añadimos al resultado
                    if (char.IsLetterOrDigit(c))
                    {
                        res += c;
                    }
                    // Si el carácter es un paréntesis de apertura, lo añadimos a la pila
                    else if (c == '(')
                    {
                        stack.Push(c);
                    }
                    // Si el carácter es un paréntesis de cierre, vaciamos la pila hasta encontrar un paréntesis de apertura
                    else if (c == ')')
                    {
                        while (stack.Count > 0 && stack.Peek() != '(')
                        {
                            res += stack.Pop();
                        }
                        stack.Pop(); // Quitar el '(' de la pila
                    }
                    // Si el carácter es un operador
                    else if (IsOperator(c))
                    {
                        while (stack.Count > 0 && Precedencia(stack.Peek()) >= Precedencia(c))
                        {
                            res += stack.Pop();
                        }
                        stack.Push(c);
                    }
                }

                // Vaciar la pila y añadir los operadores restantes al resultado
                while (stack.Count > 0)
                {
                    res += stack.Pop();
                }

                return res;
            }
            public double EvaluarPostfijo(string postfijo)
            {
                Stack<double> stack = new Stack<double>();

                for (int i = 0; i < postfijo.Length; i++)
                {
                    char c = postfijo[i];

                    if (char.IsLetterOrDigit(c))
                    {
                        // Supongamos que los operandos son números. En un caso real, debes manejarlos adecuadamente.
                        stack.Push(Convert.ToDouble(c.ToString())); // Convertir a double
                    }
                    else if (IsOperator(c))
                    {
                        double operand2 = stack.Pop();
                        double operand1 = stack.Pop();
                        double resultado = 0;

                        switch (c)
                        {
                            case '+':
                                resultado = operand1 + operand2;
                                break;
                            case '-':
                                resultado = operand1 - operand2;
                                break;
                            case '*':
                                resultado = operand1 * operand2;
                                break;
                            case '/':
                                resultado = operand1 / operand2;
                                break;
                        }
                        stack.Push(resultado);
                    }
                }

                return stack.Pop(); // El resultado final
            }
            private bool IsOperator(char c)
            {
                return c == '+' || c == '-' || c == '*' || c == '/';
            }
            private int Precedencia(char op)
            {
                if (op == '+' || op == '-')
                    return 1;
                if (op == '*' || op == '/')
                    return 2;
                return 0;
            }
        }
    }
}
