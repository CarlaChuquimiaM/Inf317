﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deteccionBordes
{
    public partial class Form1 : Form
    {
        private Bitmap img;
        public Form1()
        {
            InitializeComponent();
        }
        private static int[,] sobelX = new int[,]
        {{ -1, 0, 1 }, { -2, 0, 2 },{ -1, 0, 1 }};

        private static int[,] sobelY = new int[,]
        {{ -1, -2, -1 }, { 0, 0, 0 }, { 1, 2, 1 }};
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {}

        private Bitmap blancoNegro(Bitmap image)
        {
            Bitmap bmp = new Bitmap(image.Width, image.Height);
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color c = image.GetPixel(x, y);
                    int m = (int)((c.R + c.G + c.B) / 3);
                    Color grayColor = Color.FromArgb(m, m, m);
                    bmp.SetPixel(x, y, grayColor);
                }
            }
            return bmp;
        }

        private Bitmap ApplySobelFilter(Bitmap grayImage)
        {
            Bitmap bmp = new Bitmap(grayImage.Width, grayImage.Height);

            for (int y = 1; y < grayImage.Height - 1; y++)
            {
                for (int x = 1; x < grayImage.Width - 1; x++)
                {
                    int gx = 0;
                    int gy = 0;
                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            Color pixel = grayImage.GetPixel(x + j, y + i);
                            int intensity = pixel.R;
                            gx += intensity * sobelX[i + 1, j + 1];
                            gy += intensity * sobelY[i + 1, j + 1];
                        }
                    }

                    int g = (int)Math.Sqrt(gx * gx + gy * gy);
                    g = Math.Min(255, g); 
                    bmp.SetPixel(x, y, Color.FromArgb(g, g, g));
                }
            }
            return bmp;
        }

        private void bDetectar_Click(object sender, EventArgs e)
        {
            if (img == null){
                MessageBox.Show("Suba una imagen");
                return;
            }
            Bitmap m = blancoNegro(img);
            Bitmap borde = ApplySobelFilter(m);
            pictureBox2.Image = borde;
        }

        private void bSubir_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Archivos PNG|*.png|Archivos JPG|*.jpg";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                img = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = img;
            }

        }
    }
}
